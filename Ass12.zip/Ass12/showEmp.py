def showEmp():
    fileRead = open("D:/Python/Ass12/empData.txt","r")
    for i in fileRead.readlines():
        print(i)
    print()
