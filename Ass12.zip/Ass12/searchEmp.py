def searchEmp():
    id = int(input("Enter the id of the employee : "))
    fileRead = open("D:/Python/Ass12/empData.txt","r")
    print(fileRead.readlines()[id])
    
