import file_operations

# Create an instance of FileHandler
handler = file_operations.FileHandler('sample.txt')

# Write content to the file
handler.write_file('Soham Vaity')

# Read the file
content = handler.read_file()
print(content)  # Output: Soham Vaity

# Append content to the file
handler.append_file('\nThis is an example.')
content = handler.read_file()
print(content)
# Output:
# Soham Vaity
# This is an example.

# Count the number of lines in the file
line_count = handler.count_lines()
print(f"Number of lines: {line_count}")  # Output: Number of lines: 2

# Raise the custom exception
try:
    raise file_operations.CustomException("This is a custom exception.")
except file_operations.CustomException as e:
    print(e)  # Output: CustomException: This is a custom exception.
