# removes the latest emp

def remEmp():

    fileAppend = open("D:/Python/Ass12/empData.txt","a")
    fileRead = open("D:/Python/Ass12/empData.txt","r")
    data = fileRead.readlines()
    data = data[:-1]
    fileRead.truncate(0)
    fileAppend.writelines(data)

