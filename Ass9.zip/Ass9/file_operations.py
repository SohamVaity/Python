# file_operations.py

class FileHandler:
    def __init__(self, filename):
        self.filename = filename
    
    def read_file(self):
        with open(self.filename, 'r') as file:
            return file.read()
    
    def write_file(self, content):
        with open(self.filename, 'w') as file:
            file.write(content)
    
    def append_file(self, content):
        with open(self.filename, 'a') as file:
            file.write(content)
    
    def count_lines(self):
        with open(self.filename, 'r') as file:
            return len(file.readlines())

class CustomException(Exception):
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return f"CustomException: {self.message}"

